# DevOps practice repo

The project was created on: Docker, Python+Flask, Postgresql

## How to start the project

### Docker compose

```docker compose up --build```
> Optional: Enter the database connection data in the .env file

## How to use

1. Open the web page on http://localhost;
2. That's it.
